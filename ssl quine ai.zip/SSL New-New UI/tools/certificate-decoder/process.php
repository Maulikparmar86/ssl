<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$certificate = $input['certificate'] ?? '';

if (empty($certificate)) {
    echo json_encode(['success' => false, 'error' => 'Certificate data is required']);
    exit;
}

try {
    // Clean certificate data
    $certificate = trim($certificate);
    
    // Remove headers/footers if present
    $certificate = preg_replace('/^.*?-----BEGIN CERTIFICATE-----/s', '-----BEGIN CERTIFICATE-----', $certificate);
    $certificate = preg_replace('/-----END CERTIFICATE-----.*$/s', '-----END CERTIFICATE-----', $certificate);
    
    // If it's base64 encoded without headers, add them
    if (!strpos($certificate, '-----BEGIN CERTIFICATE-----')) {
        $certificate = "-----BEGIN CERTIFICATE-----\n" . $certificate . "\n-----END CERTIFICATE-----";
    }
    
    // Parse certificate
    $cert_resource = openssl_x509_read($certificate);
    
    if (!$cert_resource) {
        // Try to decode as base64
        $decoded = base64_decode($certificate, true);
        if ($decoded !== false) {
            $cert_resource = openssl_x509_read("-----BEGIN CERTIFICATE-----\n" . base64_encode($decoded) . "\n-----END CERTIFICATE-----");
        }
        
        if (!$cert_resource) {
            throw new Exception('Invalid certificate format. Please provide a valid PEM or base64 encoded certificate.');
        }
    }
    
    // Get certificate details
    $cert_data = openssl_x509_parse($cert_resource);
    
    if (!$cert_data) {
        throw new Exception('Failed to parse certificate');
    }
    
    // Get certificate validity
    $valid_from = $cert_data['validFrom_time_t'];
    $valid_to = $cert_data['validTo_time_t'];
    $now = time();
    $is_valid = $valid_from <= $now && $valid_to >= $now;
    $days_remaining = ceil(($valid_to - $now) / 86400);
    
    // Format serial number properly (like sslshopper.com)
    $raw_serial = $cert_data['serialNumber'] ?? 'Unknown';
    $formatted_serial = '';
    if ($raw_serial && $raw_serial !== 'Unknown') {
        $serial_hex = strtoupper($raw_serial);
        $formatted_serial = implode(':', str_split($serial_hex, 2));
    } else {
        $formatted_serial = 'Unknown';
    }
    
    // Get certificate fingerprints
    $sha1_fingerprint = openssl_x509_fingerprint($cert_resource, 'sha1');
    $sha256_fingerprint = openssl_x509_fingerprint($cert_resource, 'sha256');
    $md5_fingerprint = openssl_x509_fingerprint($cert_resource, 'md5');
    
    // Get key details
    $public_key = openssl_pkey_get_public($cert_resource);
    $key_details = openssl_pkey_get_details($public_key);
    
    // Determine key algorithm
    $key_algorithm = 'Unknown';
    if ($key_details['type'] === OPENSSL_KEYTYPE_RSA) {
        $key_algorithm = 'RSA';
    } elseif ($key_details['type'] === OPENSSL_KEYTYPE_EC) {
        $key_algorithm = 'ECDSA';
    } elseif ($key_details['type'] === OPENSSL_KEYTYPE_DSA) {
        $key_algorithm = 'DSA';
    }
    
    // Get Subject Alternative Names
    $subject_alt_names = [];
    if (isset($cert_data['extensions']['subjectAltName'])) {
        $sans = explode(', ', $cert_data['extensions']['subjectAltName']);
        foreach ($sans as $san) {
            if (strpos($san, 'DNS:') === 0) {
                $subject_alt_names[] = substr($san, 4);
            }
        }
    }
    
    // Get key usage
    $key_usage = [];
    if (isset($cert_data['extensions']['keyUsage'])) {
        $key_usage = explode(', ', $cert_data['extensions']['keyUsage']);
    }
    
    // Get extended key usage
    $extended_key_usage = [];
    if (isset($cert_data['extensions']['extendedKeyUsage'])) {
        $extended_key_usage = explode(', ', $cert_data['extensions']['extendedKeyUsage']);
    }
    
    // Get certificate details
    $subject = $cert_data['subject']['CN'] ?? 'Unknown';
    $issuer = $cert_data['issuer']['CN'] ?? 'Unknown';
    $organization = $cert_data['subject']['O'] ?? '';
    $organizational_unit = $cert_data['subject']['OU'] ?? '';
    $country = $cert_data['subject']['C'] ?? '';
    $state = $cert_data['subject']['ST'] ?? '';
    $locality = $cert_data['subject']['L'] ?? '';
    
    echo json_encode([
        'success' => true,
        'certificate' => [
            'isValid' => $is_valid,
            'subject' => $subject,
            'issuer' => $issuer,
            'organization' => $organization,
            'organizationalUnit' => $organizational_unit,
            'country' => $country,
            'state' => $state,
            'locality' => $locality,
            'validFrom' => date('c', $valid_from),
            'validTo' => date('c', $valid_to),
            'daysRemaining' => $days_remaining,
            'serialNumber' => $formatted_serial,
            'serialNumberRaw' => $raw_serial,
            'signatureAlgorithm' => $cert_data['signatureTypeSN'] ?? 'Unknown',
            'keyAlgorithm' => $key_algorithm,
            'keySize' => $key_details['bits'],
            'subjectAltNames' => $subject_alt_names,
            'keyUsage' => $key_usage,
            'extendedKeyUsage' => $extended_key_usage,
            'sha1Fingerprint' => $sha1_fingerprint,
            'sha256Fingerprint' => $sha256_fingerprint,
            'md5Fingerprint' => $md5_fingerprint,
            'version' => $cert_data['version'] + 1,
            'checkedAt' => date('Y-m-d H:i:s')
        ]
    ]);
    
    // Clean up resources
    openssl_x509_free($cert_resource);
    openssl_pkey_free($public_key);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Certificate decoding failed: ' . $e->getMessage()]);
}
?>

