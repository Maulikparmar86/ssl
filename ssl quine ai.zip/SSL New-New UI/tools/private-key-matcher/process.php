<?php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$certificate = $input['certificate'] ?? '';
$privateKey = $input['privateKey'] ?? '';

if (empty($certificate) || empty($privateKey)) {
    echo json_encode(['success' => false, 'error' => 'Both certificate and private key are required']);
    exit;
}

try {
    // Clean the certificate and private key data
    $certificate = trim($certificate);
    $privateKey = trim($privateKey);
    
    // Validate certificate format
    if (!preg_match('/-----BEGIN CERTIFICATE-----/', $certificate) || !preg_match('/-----END CERTIFICATE-----/', $certificate)) {
        throw new Exception('Invalid certificate format. Please provide a valid PEM certificate.');
    }
    
    // Validate private key format
    if (!preg_match('/-----BEGIN (RSA )?PRIVATE KEY-----/', $privateKey) || !preg_match('/-----END (RSA )?PRIVATE KEY-----/', $privateKey)) {
        throw new Exception('Invalid private key format. Please provide a valid PEM private key.');
    }
    
    // Parse certificate
    $cert_resource = openssl_x509_read($certificate);
    if (!$cert_resource) {
        throw new Exception('Failed to parse certificate. Please check the certificate format.');
    }
    
    $cert_data = openssl_x509_parse($cert_resource);
    if (!$cert_data) {
        throw new Exception('Failed to parse certificate data.');
    }
    
    // Parse private key
    $key_resource = openssl_pkey_get_private($privateKey);
    if (!$key_resource) {
        throw new Exception('Failed to parse private key. Please check the private key format.');
    }
    
    $key_details = openssl_pkey_get_details($key_resource);
    if (!$key_details) {
        throw new Exception('Failed to get private key details.');
    }
    
    // Extract public key from certificate
    $cert_public_key = openssl_pkey_get_public($cert_resource);
    if (!$cert_public_key) {
        throw new Exception('Failed to extract public key from certificate.');
    }
    
    $cert_public_details = openssl_pkey_get_details($cert_public_key);
    if (!$cert_public_details) {
        throw new Exception('Failed to get certificate public key details.');
    }
    
    // Compare public keys to check if they match
    $is_match = false;
    if ($cert_public_details['key'] === $key_details['key']) {
        $is_match = true;
    }
    
    // Format serial number properly
    $raw_serial = $cert_data['serialNumber'] ?? 'Unknown';
    $formatted_serial = '';
    if ($raw_serial && $raw_serial !== 'Unknown') {
        $serial_hex = strtoupper($raw_serial);
        $formatted_serial = implode(':', str_split($serial_hex, 2));
    } else {
        $formatted_serial = 'Unknown';
    }
    
    // Get certificate fingerprints
    $sha1_fingerprint = openssl_x509_fingerprint($cert_resource, 'sha1');
    $sha256_fingerprint = openssl_x509_fingerprint($cert_resource, 'sha256');
    
    // Determine key algorithm
    $key_algorithm = 'Unknown';
    if ($key_details['type'] === OPENSSL_KEYTYPE_RSA) {
        $key_algorithm = 'RSA';
    } elseif ($key_details['type'] === OPENSSL_KEYTYPE_EC) {
        $key_algorithm = 'ECDSA';
    } elseif ($key_details['type'] === OPENSSL_KEYTYPE_DSA) {
        $key_algorithm = 'DSA';
    }
    
    // Get certificate validity
    $current_time = time();
    $valid_from = $cert_data['validFrom_time_t'];
    $valid_until = $cert_data['validTo_time_t'];
    $is_expired = $valid_until < $current_time;
    $days_until_expiry = floor(($valid_until - $current_time) / 86400);
    
    // Get Subject Alternative Names
    $subject_alt_names = [];
    if (isset($cert_data['extensions']['subjectAltName'])) {
        $sans = explode(', ', $cert_data['extensions']['subjectAltName']);
        foreach ($sans as $san) {
            if (strpos($san, 'DNS:') === 0) {
                $subject_alt_names[] = substr($san, 4);
            }
        }
    }
    
    // Get key usage
    $key_usage = [];
    if (isset($cert_data['extensions']['keyUsage'])) {
        $key_usage = explode(', ', $cert_data['extensions']['keyUsage']);
    }
    
    // Get extended key usage
    $extended_key_usage = [];
    if (isset($cert_data['extensions']['extendedKeyUsage'])) {
        $extended_key_usage = explode(', ', $cert_data['extensions']['extendedKeyUsage']);
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'isMatch' => $is_match,
            'certificateSubject' => $cert_data['subject']['CN'] ?? 'Unknown',
            'certificateIssuer' => $cert_data['issuer']['CN'] ?? 'Unknown',
            'certificateSerial' => $formatted_serial,
            'certificateSerialRaw' => $raw_serial,
            'keyAlgorithm' => $key_algorithm,
            'keySize' => $key_details['bits'],
            'certificateValidFrom' => date('Y-m-d H:i:s', $valid_from),
            'certificateValidUntil' => date('Y-m-d H:i:s', $valid_until),
            'isExpired' => $is_expired,
            'daysUntilExpiry' => $days_until_expiry,
            'sha1Fingerprint' => $sha1_fingerprint,
            'sha256Fingerprint' => $sha256_fingerprint,
            'signatureAlgorithm' => $cert_data['signatureTypeSN'] ?? 'Unknown',
            'subjectAltNames' => $subject_alt_names,
            'keyUsage' => $key_usage,
            'extendedKeyUsage' => $extended_key_usage,
            'organization' => $cert_data['subject']['O'] ?? '',
            'organizationalUnit' => $cert_data['subject']['OU'] ?? '',
            'country' => $cert_data['subject']['C'] ?? '',
            'state' => $cert_data['subject']['ST'] ?? '',
            'locality' => $cert_data['subject']['L'] ?? '',
            'checkedAt' => date('Y-m-d H:i:s')
        ]
    ]);
    
    // Clean up resources
    openssl_x509_free($cert_resource);
    openssl_pkey_free($key_resource);
    openssl_pkey_free($cert_public_key);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
