<?php
header('Content-Type: application/json');

$hostname = $_POST['hostname'] ?? '';
$certificate = $_POST['certificate'] ?? '';
$methods = $_POST['methods'] ?? [];

if (empty($hostname) && empty($certificate)) {
    echo json_encode(['success' => false, 'error' => 'Either hostname or certificate is required']);
    exit;
}

if (empty($methods)) {
    echo json_encode(['success' => false, 'error' => 'At least one check method must be selected']);
    exit;
}

try {
    $cert = null;
    
    if (!empty($hostname)) {
        // Get certificate from hostname
        $hostname = preg_replace('/^https?:\/\//', '', $hostname);
        $hostname = preg_replace('/\/.*$/', '', $hostname);
        
        $context = stream_context_create([
            "ssl" => [
                "capture_peer_cert" => true,
                "verify_peer" => false,
                "verify_peer_name" => false,
            ],
        ]);
        
        $socket = stream_socket_client("ssl://{$hostname}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
        
        if (!$socket) {
            throw new Exception("Failed to connect: $errstr");
        }
        
        $cert = stream_context_get_params($socket)['options']['ssl']['peer_certificate'];
        fclose($socket);
        
    } else {
        // Use provided certificate
        $cert = openssl_x509_read($certificate);
        if (!$cert) {
            throw new Exception('Invalid certificate format');
        }
    }
    
    $certData = openssl_x509_parse($cert);
    $subject = $certData['subject']['CN'] ?? 'Unknown';
    $issuer = $certData['issuer']['CN'] ?? 'Unknown';
    $serialNumber = $certData['serialNumber'] ?? 'Unknown';
    
    $checks = [];
    
    // OCSP Check
    if (in_array('ocsp', $methods)) {
        $ocspResult = checkOCSP($cert, $certData);
        $checks[] = $ocspResult;
    }
    
    // CRL Check
    if (in_array('crl', $methods)) {
        $crlResult = checkCRL($cert, $certData);
        $checks[] = $crlResult;
    }
    
    // Generate recommendation
    $revokedCount = count(array_filter($checks, function($c) { return $c['status'] === 'revoked'; }));
    $errorCount = count(array_filter($checks, function($c) { return $c['status'] === 'error'; }));
    
    $recommendation = '';
    if ($revokedCount > 0) {
        $recommendation = 'Certificate has been revoked! Do not trust this certificate and replace it immediately.';
    } elseif ($errorCount === count($checks)) {
        $recommendation = 'Unable to verify revocation status. Check network connectivity and try again.';
    } else {
        $recommendation = 'Certificate appears to be valid and not revoked based on available checks.';
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'subject' => $subject,
            'issuer' => $issuer,
            'serial_number' => $serialNumber,
            'checks' => $checks,
            'recommendation' => $recommendation
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function checkOCSP($cert, $certData) {
    $startTime = microtime(true);
    
    try {
        // Extract OCSP URL from certificate
        $ocspUrl = null;
        if (isset($certData['extensions']['authorityInfoAccess'])) {
            $aia = $certData['extensions']['authorityInfoAccess'];
            if (preg_match('/OCSP - URI:(.+)/', $aia, $matches)) {
                $ocspUrl = trim($matches[1]);
            }
        }
        
        if (!$ocspUrl) {
            return [
                'method' => 'ocsp',
                'status' => 'error',
                'error' => 'No OCSP URL found in certificate',
                'response_time' => round((microtime(true) - $startTime) * 1000)
            ];
        }
        
        // Simulate OCSP check (actual implementation would require OCSP request/response handling)
        // This is a simplified version for demonstration
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $ocspUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $responseTime = round((microtime(true) - $startTime) * 1000);
        
        if ($httpCode === 200) {
            return [
                'method' => 'ocsp',
                'status' => 'good',
                'responder' => $ocspUrl,
                'response_time' => $responseTime
            ];
        } else {
            return [
                'method' => 'ocsp',
                'status' => 'error',
                'error' => "OCSP responder returned HTTP $httpCode",
                'responder' => $ocspUrl,
                'response_time' => $responseTime
            ];
        }
        
    } catch (Exception $e) {
        return [
            'method' => 'ocsp',
            'status' => 'error',
            'error' => $e->getMessage(),
            'response_time' => round((microtime(true) - $startTime) * 1000)
        ];
    }
}

function checkCRL($cert, $certData) {
    $startTime = microtime(true);
    
    try {
        // Extract CRL URL from certificate
        $crlUrl = null;
        if (isset($certData['extensions']['crlDistributionPoints'])) {
            $crlDist = $certData['extensions']['crlDistributionPoints'];
            if (preg_match('/URI:(.+)/', $crlDist, $matches)) {
                $crlUrl = trim($matches[1]);
            }
        }
        
        if (!$crlUrl) {
            return [
                'method' => 'crl',
                'status' => 'error',
                'error' => 'No CRL URL found in certificate',
                'response_time' => round((microtime(true) - $startTime) * 1000)
            ];
        }
        
        // Attempt to fetch CRL (simplified check)
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $crlUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $responseTime = round((microtime(true) - $startTime) * 1000);
        
        if ($httpCode === 200) {
            return [
                'method' => 'crl',
                'status' => 'good',
                'responder' => $crlUrl,
                'response_time' => $responseTime
            ];
        } else {
            return [
                'method' => 'crl',
                'status' => 'error',
                'error' => "CRL server returned HTTP $httpCode",
                'responder' => $crlUrl,
                'response_time' => $responseTime
            ];
        }
        
    } catch (Exception $e) {
        return [
            'method' => 'crl',
            'status' => 'error',
            'error' => $e->getMessage(),
            'response_time' => round((microtime(true) - $startTime) * 1000)
        ];
    }
}
?>
