<?php
header('Content-Type: application/json');

$domain = $_POST['domain'] ?? '';
if (empty($domain)) {
    echo json_encode(['success' => false, 'error' => 'Domain is required']);
    exit;
}

$domain = preg_replace('/^https?:\/\//', '', $domain);
$domain = preg_replace('/\/.*$/', '', $domain);

try {
    // Get certificate information
    $context = stream_context_create([
        "ssl" => [
            "capture_peer_cert" => true,
            "verify_peer" => false,
            "verify_peer_name" => false,
            "allow_self_signed" => true,
        ],
    ]);
    
    $socket = stream_socket_client("ssl://{$domain}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
    
    if (!$socket) {
        throw new Exception("Failed to connect to {$domain}:443 - $errstr");
    }
    
    $params = stream_context_get_params($socket);
    $cert = $params['options']['ssl']['peer_certificate'] ?? null;
    fclose($socket);
    
    if (!$cert) {
        throw new Exception('No certificate found');
    }
    
    $certData = openssl_x509_parse($cert);
    
    if (!$certData) {
        throw new Exception('Failed to parse certificate data');
    }
    
    $currentTime = time();
    $validFrom = $certData['validFrom_time_t'];
    $validUntil = $certData['validTo_time_t'];
    
    // Calculate days until expiry
    $daysUntilExpiry = floor(($validUntil - $currentTime) / 86400);
    
    // Check if certificate is expired or not yet valid
    $isExpired = $validUntil < $currentTime;
    $isNotYetValid = $validFrom > $currentTime;
    
    // Format serial number properly (like sslshopper.com)
    $raw_serial = $certData['serialNumber'] ?? 'Unknown';
    $formatted_serial = '';
    if ($raw_serial && $raw_serial !== 'Unknown') {
        // Convert to proper hex format with colons
        $serial_hex = strtoupper($raw_serial);
        $formatted_serial = implode(':', str_split($serial_hex, 2));
    } else {
        $formatted_serial = 'Unknown';
    }
    
    // Get certificate fingerprints
    $sha1_fingerprint = openssl_x509_fingerprint($cert, 'sha1');
    $sha256_fingerprint = openssl_x509_fingerprint($cert, 'sha256');
    
    // Determine status
    $status = 'Good';
    if ($isExpired) {
        $status = 'Expired';
    } elseif ($isNotYetValid) {
        $status = 'Not Yet Valid';
    } elseif ($daysUntilExpiry <= 7) {
        $status = 'Critical';
    } elseif ($daysUntilExpiry <= 30) {
        $status = 'Warning';
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'domain' => $domain,
            'subject' => $certData['subject']['CN'] ?? 'Unknown',
            'issuer' => $certData['issuer']['CN'] ?? 'Unknown',
            'organization' => $certData['subject']['O'] ?? '',
            'valid_from' => date('Y-m-d H:i:s', $validFrom),
            'valid_until' => date('Y-m-d H:i:s', $validUntil),
            'serial_number' => $formatted_serial,
            'serial_number_raw' => $raw_serial,
            'signature_algorithm' => $certData['signatureTypeSN'] ?? 'Unknown',
            'sha1_fingerprint' => $sha1_fingerprint,
            'sha256_fingerprint' => $sha256_fingerprint,
            'days_until_expiry' => $daysUntilExpiry,
            'is_expired' => $isExpired,
            'is_not_yet_valid' => $isNotYetValid,
            'status' => $status,
            'checked_at' => date('Y-m-d H:i:s')
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
