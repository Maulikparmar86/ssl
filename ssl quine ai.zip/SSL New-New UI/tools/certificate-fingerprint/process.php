<?php
header('Content-Type: application/json');

$hostname = $_POST['hostname'] ?? '';
$certificate = $_POST['certificate'] ?? '';

if (empty($hostname) && empty($certificate)) {
    echo json_encode(['success' => false, 'error' => 'Either hostname or certificate is required']);
    exit;
}

try {
    $cert = null;
    $subject = null;
    
    if (!empty($hostname)) {
        // Get certificate from hostname
        $hostname = preg_replace('/^https?:\/\//', '', $hostname);
        $hostname = preg_replace('/\/.*$/', '', $hostname);
        
        $context = stream_context_create([
            "ssl" => [
                "capture_peer_cert" => true,
                "verify_peer" => false,
                "verify_peer_name" => false,
            ],
        ]);
        
        $socket = stream_socket_client("ssl://{$hostname}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
        
        if (!$socket) {
            throw new Exception("Failed to connect: $errstr");
        }
        
        $cert = stream_context_get_params($socket)['options']['ssl']['peer_certificate'];
        fclose($socket);
        
        $certData = openssl_x509_parse($cert);
        $subject = $certData['subject']['CN'] ?? $hostname;
        
    } else {
        // Use provided certificate
        $cert = openssl_x509_read($certificate);
        if (!$cert) {
            throw new Exception('Invalid certificate format');
        }
        
        $certData = openssl_x509_parse($cert);
        $subject = $certData['subject']['CN'] ?? 'Unknown';
    }
    
    // Get certificate in DER format for fingerprinting
    openssl_x509_export($cert, $certPem);
    $certDer = base64_decode(preg_replace('/-----[^-]+-----/', '', str_replace(["\r", "\n"], '', $certPem)));
    
    // Generate fingerprints
    $sha256 = strtoupper(hash('sha256', $certDer));
    $sha1 = strtoupper(hash('sha1', $certDer));
    $md5 = strtoupper(hash('md5', $certDer));
    
    // Format fingerprints with colons
    $sha256 = implode(':', str_split($sha256, 2));
    $sha1 = implode(':', str_split($sha1, 2));
    $md5 = implode(':', str_split($md5, 2));
    
    echo json_encode([
        'success' => true,
        'data' => [
            'subject' => $subject,
            'sha256' => $sha256,
            'sha1' => $sha1,
            'md5' => $md5
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
