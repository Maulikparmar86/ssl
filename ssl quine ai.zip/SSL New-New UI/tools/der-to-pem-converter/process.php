<?php
header('Content-Type: application/json');

$hexData = $_POST['hex_data'] ?? '';
$derFile = $_FILES['der_file'] ?? null;

if (empty($hexData) && !$derFile) {
    echo json_encode(['success' => false, 'error' => 'Either hex data or DER file is required']);
    exit;
}

try {
    $derBinary = '';
    $filename = 'certificate.pem';
    
    if ($derFile) {
        // Handle file upload
        if ($derFile['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('File upload failed');
        }
        
        $derBinary = file_get_contents($derFile['tmp_name']);
        $filename = pathinfo($derFile['name'], PATHINFO_FILENAME) . '.pem';
        
    } else {
        // Handle hex data
        $hexData = preg_replace('/[^0-9a-fA-F]/', '', $hexData);
        if (strlen($hexData) % 2 !== 0) {
            throw new Exception('Invalid hex data - must have even number of characters');
        }
        
        $derBinary = hex2bin($hexData);
        if ($derBinary === false) {
            throw new Exception('Invalid hex data format');
        }
    }
    
    // Convert DER to PEM
    $pemBase64 = base64_encode($derBinary);
    $pemFormatted = chunk_split($pemBase64, 64, "\n");
    $pemContent = "-----BEGIN CERTIFICATE-----\n" . $pemFormatted . "-----END CERTIFICATE-----\n";
    
    // Try to parse the certificate to validate and get info
    $cert = openssl_x509_read($pemContent);
    $subject = 'Unknown';
    
    if ($cert) {
        $certData = openssl_x509_parse($cert);
        $subject = $certData['subject']['CN'] ?? 'Unknown Certificate';
    } else {
        // Try as CSR
        $csrContent = "-----BEGIN CERTIFICATE REQUEST-----\n" . $pemFormatted . "-----END CERTIFICATE REQUEST-----\n";
        $csrSubject = openssl_csr_get_subject($csrContent);
        if ($csrSubject) {
            $subject = 'Certificate Signing Request';
            $pemContent = $csrContent;
        }
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'filename' => $filename,
            'der_size' => strlen($derBinary),
            'pem_size' => strlen($pemContent),
            'subject' => $subject,
            'pem_content' => $pemContent
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
