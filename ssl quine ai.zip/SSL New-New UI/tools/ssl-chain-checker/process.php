<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$hostname = $_POST['hostname'] ?? '';
if (empty($hostname)) {
    echo json_encode(['success' => false, 'error' => 'Hostname is required']);
    exit;
}

$hostname = preg_replace('/^https?:\/\//', '', $hostname);
$hostname = preg_replace('/\/.*$/', '', $hostname);

try {
    // Get certificate chain
    $context = stream_context_create([
        "ssl" => [
            "capture_peer_cert_chain" => true,
            "verify_peer" => false,
            "verify_peer_name" => false,
            "allow_self_signed" => true,
        ],
    ]);
    
    $socket = stream_socket_client("ssl://{$hostname}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
    
    if (!$socket) {
        throw new Exception("Failed to connect to {$hostname}:443 - $errstr (Error: $errno)");
    }
    
    $params = stream_context_get_params($socket);
    $certChain = $params['options']['ssl']['peer_certificate_chain'] ?? [];
    fclose($socket);
    
    if (empty($certChain)) {
        throw new Exception('No certificate chain found for ' . $hostname);
    }
    
    $certificates = [];
    $chainValid = true;
    $currentTime = time();
    
    foreach ($certChain as $index => $cert) {
        $certData = openssl_x509_parse($cert);
        
        if (!$certData) {
            throw new Exception('Failed to parse certificate data');
        }
        
        $type = 'Intermediate Certificate';
        if ($index === 0) {
            $type = 'End Entity Certificate';
        } elseif ($index === count($certChain) - 1) {
            $type = 'Root Certificate';
        }
        
        // Check if certificate is expired
        $isExpired = $certData['validTo_time_t'] < $currentTime;
        $isNotYetValid = $certData['validFrom_time_t'] > $currentTime;
        
        if ($isExpired || $isNotYetValid) {
            $chainValid = false;
        }
        
        // Get additional certificate details
        $subjectAltNames = [];
        if (isset($certData['extensions']['subjectAltName'])) {
            $san = $certData['extensions']['subjectAltName'];
            preg_match_all('/(?:DNS|IP Address):([^,\s]+)/', $san, $matches);
            if (isset($matches[1])) {
                $subjectAltNames = $matches[1];
            }
        }
        
        // Get key usage and extended key usage
        $keyUsage = '';
        if (isset($certData['extensions']['keyUsage'])) {
            $keyUsage = $certData['extensions']['keyUsage'];
        }
        
        $extendedKeyUsage = '';
        if (isset($certData['extensions']['extendedKeyUsage'])) {
            $extendedKeyUsage = $certData['extensions']['extendedKeyUsage'];
        }
        
        // Format serial number properly (like sslshopper.com)
        $raw_serial = $certData['serialNumber'] ?? 'Unknown';
        $formatted_serial = '';
        if ($raw_serial && $raw_serial !== 'Unknown') {
            // Convert to proper hex format with colons
            $serial_hex = strtoupper($raw_serial);
            $formatted_serial = implode(':', str_split($serial_hex, 2));
        } else {
            $formatted_serial = 'Unknown';
        }
        
        // Get certificate fingerprints
        $sha1_fingerprint = openssl_x509_fingerprint($cert, 'sha1');
        $sha256_fingerprint = openssl_x509_fingerprint($cert, 'sha256');
        
        $certificates[] = [
            'type' => $type,
            'subject' => $certData['subject']['CN'] ?? 'Unknown',
            'issuer' => $certData['issuer']['CN'] ?? 'Unknown',
            'valid_from' => date('Y-m-d H:i:s', $certData['validFrom_time_t']),
            'valid_to' => date('Y-m-d H:i:s', $certData['validTo_time_t']),
            'serial' => $formatted_serial,
            'serial_raw' => $raw_serial,
            'signature_algorithm' => $certData['signatureTypeSN'] ?? 'Unknown',
            'key_size' => $certData['signatureTypeSN'] ?? 'Unknown',
            'subject_alt_names' => $subjectAltNames,
            'key_usage' => $keyUsage,
            'extended_key_usage' => $extendedKeyUsage,
            'is_expired' => $isExpired,
            'is_not_yet_valid' => $isNotYetValid,
            'days_until_expiry' => floor(($certData['validTo_time_t'] - $currentTime) / 86400),
            'organization' => $certData['subject']['O'] ?? '',
            'organizational_unit' => $certData['subject']['OU'] ?? '',
            'country' => $certData['subject']['C'] ?? '',
            'state' => $certData['subject']['ST'] ?? '',
            'locality' => $certData['subject']['L'] ?? '',
            'sha1_fingerprint' => $sha1_fingerprint,
            'sha256_fingerprint' => $sha256_fingerprint
        ];
    }
    
    // Verify chain integrity
    $chainIntegrity = true;
    for ($i = 0; $i < count($certificates) - 1; $i++) {
        $currentCert = $certificates[$i];
        $nextCert = $certificates[$i + 1];
        
        // Check if issuer of current cert matches subject of next cert
        if ($currentCert['issuer'] !== $nextCert['subject']) {
            $chainIntegrity = false;
            break;
        }
    }
    
    $rootCA = end($certificates)['issuer'];
    $chainLength = count($certificates);
    
    // Determine chain status
    $chainStatus = 'Valid';
    if (!$chainValid) {
        $chainStatus = 'Invalid - Contains expired certificates';
    } elseif (!$chainIntegrity) {
        $chainStatus = 'Invalid - Chain integrity broken';
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'chain_valid' => $chainValid && $chainIntegrity,
            'chain_status' => $chainStatus,
            'chain_length' => $chainLength,
            'chain_integrity' => $chainIntegrity,
            'root_ca' => $rootCA,
            'certificates' => $certificates,
            'hostname' => $hostname,
            'checked_at' => date('Y-m-d H:i:s')
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
