<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$domain = $_POST['domain'] ?? '';
$logoStyle = $_POST['logo_style'] ?? 'modern';
$colorScheme = $_POST['color_scheme'] ?? 'green';
$size = $_POST['size'] ?? 'medium';
$showExpiry = isset($_POST['show_expiry']);
$clickable = isset($_POST['clickable']);

if (empty($domain)) {
    echo json_encode(['success' => false, 'error' => 'Domain is required']);
    exit;
}

// Clean domain
$domain = strtolower(trim($domain));
$domain = preg_replace('/^https?:\/\//', '', $domain);
$domain = preg_replace('/^www\./', '', $domain);
$domain = preg_replace('/\/.*$/', '', $domain);

try {
    // Get SSL certificate info for the domain (optional)
    $sslInfo = null;
    $expiryText = '';
    
    if ($showExpiry) {
        try {
            $context = stream_context_create([
                "ssl" => [
                    "capture_peer_cert" => true,
                    "verify_peer" => false,
                    "verify_peer_name" => false,
                ],
            ]);
            
            $socket = stream_socket_client("ssl://{$domain}:443", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $context);
            
            if ($socket) {
                $cert = stream_context_get_params($socket)['options']['ssl']['peer_certificate'];
                fclose($socket);
                
                if ($cert) {
                    $certData = openssl_x509_parse($cert);
                    $expiryDate = date('M Y', $certData['validTo_time_t']);
                    $expiryText = "Valid until {$expiryDate}";
                }
            }
        } catch (Exception $e) {
            // Ignore SSL check errors for logo generation
        }
    }
    
    // Define size dimensions
    $sizes = [
        'small' => ['width' => 120, 'height' => 60],
        'medium' => ['width' => 160, 'height' => 80],
        'large' => ['width' => 200, 'height' => 100]
    ];
    
    $dimensions = $sizes[$size];
    
    // Define color schemes
    $colors = [
        'green' => ['bg' => '#28a745', 'text' => '#ffffff', 'border' => '#1e7e34'],
        'blue' => ['bg' => '#007bff', 'text' => '#ffffff', 'border' => '#0056b3'],
        'dark' => ['bg' => '#343a40', 'text' => '#ffffff', 'border' => '#23272b'],
        'light' => ['bg' => '#f8f9fa', 'text' => '#495057', 'border' => '#dee2e6']
    ];
    
    $colorPalette = $colors[$colorScheme];
    
    // Generate unique badge ID
    $badgeId = 'ssl-badge-' . md5($domain . time());
    
    // Create logo HTML based on style
    $logoHtml = generateLogoHtml($logoStyle, $domain, $dimensions, $colorPalette, $expiryText, $badgeId);
    
    // Create embed code
    $embedCode = $logoHtml;
    if ($clickable) {
        $checkUrl = "https://yourdomain.com/tools/ssl-checker/?hostname=" . urlencode($domain);
        $embedCode = "<a href=\"{$checkUrl}\" target=\"_blank\" rel=\"noopener\" title=\"Check SSL Certificate for {$domain}\">{$logoHtml}</a>";
    }
    
    // Generate CSS
    $cssCode = generateCSS($badgeId, $dimensions, $colorPalette);
    
    $result = [
        'success' => true,
        'data' => [
            'domain' => $domain,
            'style' => ucfirst($logoStyle),
            'color_scheme' => ucfirst($colorScheme),
            'size' => ucfirst($size) . " ({$dimensions['width']}x{$dimensions['height']})",
            'logo_html' => $logoHtml,
            'embed_code' => $embedCode,
            'css_code' => $cssCode,
            'badge_id' => $badgeId
        ]
    ];
    
    echo json_encode($result);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

function generateLogoHtml($style, $domain, $dimensions, $colors, $expiryText, $badgeId) {
    $width = $dimensions['width'];
    $height = $dimensions['height'];
    
    switch ($style) {
        case 'modern':
            return "<div class=\"ssl-badge ssl-badge-modern\" id=\"{$badgeId}\">
                <div class=\"ssl-icon\">🔒</div>
                <div class=\"ssl-text\">
                    <div class=\"ssl-title\">SSL SECURED</div>
                    <div class=\"ssl-domain\">{$domain}</div>
                    " . ($expiryText ? "<div class=\"ssl-expiry\">{$expiryText}</div>" : "") . "
                </div>
            </div>";
            
        case 'classic':
            return "<div class=\"ssl-badge ssl-badge-classic\" id=\"{$badgeId}\">
                <div class=\"ssl-seal\">
                    <div class=\"ssl-icon\">🛡️</div>
                    <div class=\"ssl-title\">SECURE</div>
                    <div class=\"ssl-subtitle\">SSL Certificate</div>
                    <div class=\"ssl-domain\">{$domain}</div>
                    " . ($expiryText ? "<div class=\"ssl-expiry\">{$expiryText}</div>" : "") . "
                </div>
            </div>";
            
        case 'minimal':
            return "<div class=\"ssl-badge ssl-badge-minimal\" id=\"{$badgeId}\">
                <span class=\"ssl-icon\">🔒</span>
                <span class=\"ssl-text\">SSL Secured</span>
                " . ($expiryText ? "<span class=\"ssl-expiry\">{$expiryText}</span>" : "") . "
            </div>";
            
        case 'certificate':
            return "<div class=\"ssl-badge ssl-badge-certificate\" id=\"{$badgeId}\">
                <div class=\"cert-header\">SSL CERTIFICATE</div>
                <div class=\"cert-body\">
                    <div class=\"cert-icon\">📜</div>
                    <div class=\"cert-domain\">{$domain}</div>
                    <div class=\"cert-status\">✓ VERIFIED</div>
                    " . ($expiryText ? "<div class=\"cert-expiry\">{$expiryText}</div>" : "") . "
                </div>
            </div>";
            
        case 'shield':
            return "<div class=\"ssl-badge ssl-badge-shield\" id=\"{$badgeId}\">
                <div class=\"shield-icon\">🛡️</div>
                <div class=\"shield-content\">
                    <div class=\"shield-title\">PROTECTED</div>
                    <div class=\"shield-subtitle\">SSL Encryption</div>
                    <div class=\"shield-domain\">{$domain}</div>
                    " . ($expiryText ? "<div class=\"shield-expiry\">{$expiryText}</div>" : "") . "
                </div>
            </div>";
            
        default:
            return generateLogoHtml('modern', $domain, $dimensions, $colors, $expiryText, $badgeId);
    }
}

function generateCSS($badgeId, $dimensions, $colors) {
    $width = $dimensions['width'];
    $height = $dimensions['height'];
    $bg = $colors['bg'];
    $text = $colors['text'];
    $border = $colors['border'];
    
    return "#{$badgeId} {
    display: inline-block;
    width: {$width}px;
    height: {$height}px;
    background: {$bg};
    color: {$text};
    border: 2px solid {$border};
    border-radius: 8px;
    padding: 8px;
    text-align: center;
    font-family: Arial, sans-serif;
    font-size: 12px;
    line-height: 1.2;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    transition: transform 0.2s ease;
}

#{$badgeId}:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

#{$badgeId} .ssl-icon,
#{$badgeId} .shield-icon,
#{$badgeId} .cert-icon {
    font-size: 18px;
    margin-bottom: 4px;
}

#{$badgeId} .ssl-title,
#{$badgeId} .shield-title,
#{$badgeId} .cert-header {
    font-weight: bold;
    font-size: 10px;
    margin-bottom: 2px;
}

#{$badgeId} .ssl-domain,
#{$badgeId} .shield-domain,
#{$badgeId} .cert-domain {
    font-size: 11px;
    font-weight: bold;
    margin-bottom: 2px;
}

#{$badgeId} .ssl-expiry,
#{$badgeId} .shield-expiry,
#{$badgeId} .cert-expiry {
    font-size: 9px;
    opacity: 0.9;
}";
}
?>
