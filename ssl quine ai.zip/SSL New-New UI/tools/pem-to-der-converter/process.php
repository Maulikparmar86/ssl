<?php
header('Content-Type: application/json');

$pemContent = $_POST['pem_content'] ?? '';
$filename = $_POST['filename'] ?? 'certificate.der';

if (empty($pemContent)) {
    echo json_encode(['success' => false, 'error' => 'PEM content is required']);
    exit;
}

try {
    // Validate PEM format
    if (!preg_match('/-----BEGIN [^-]+-----/', $pemContent)) {
        throw new Exception('Invalid PEM format - missing BEGIN header');
    }
    
    if (!preg_match('/-----END [^-]+-----/', $pemContent)) {
        throw new Exception('Invalid PEM format - missing END header');
    }
    
    // Try to read as certificate first
    $cert = openssl_x509_read($pemContent);
    $subject = 'Unknown';
    
    if ($cert) {
        // It's a certificate
        $certData = openssl_x509_parse($cert);
        $subject = $certData['subject']['CN'] ?? 'Unknown Certificate';
        
        // Export to DER format
        openssl_x509_export($cert, $pemOut);
        
    } else {
        // Try as CSR
        $csr = openssl_csr_get_subject($pemContent);
        if ($csr) {
            $subject = 'Certificate Signing Request';
            $pemOut = $pemContent;
        } else {
            throw new Exception('Invalid certificate or CSR format');
        }
    }
    
    // Convert PEM to DER (remove headers and decode base64)
    $pemClean = preg_replace('/-----[^-]+-----/', '', $pemOut);
    $pemClean = str_replace(["\r", "\n", " "], '', $pemClean);
    $derBinary = base64_decode($pemClean);
    
    if ($derBinary === false) {
        throw new Exception('Failed to decode base64 content');
    }
    
    // Ensure filename has .der extension
    if (!preg_match('/\.der$/i', $filename)) {
        $filename .= '.der';
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'filename' => $filename,
            'original_size' => strlen($pemContent),
            'der_size' => strlen($derBinary),
            'subject' => $subject,
            'der_base64' => base64_encode($derBinary),
            'der_hex' => bin2hex($derBinary)
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
