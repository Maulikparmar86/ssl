<?php
// Prevent any output before JSON
ob_start();

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Function to return JSON response and exit
function returnJson($data, $statusCode = 200) {
    // Clear any output buffer
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    http_response_code($statusCode);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST');
    header('Access-Control-Allow-Headers: Content-Type');
    
    echo json_encode($data);
    exit;
}

// Custom error handler
function handleError($errno, $errstr, $errfile, $errline) {
    file_put_contents(__DIR__ . '/ssl_generate_error.log', date('c') . " PHP Error: $errstr in $errfile on line $errline\n", FILE_APPEND);
    returnJson([
        'success' => false,
        'error' => "PHP Error: $errstr in $errfile on line $errline"
    ], 500);
}

// Set error handler
set_error_handler('handleError');

function sanitize_dn_field($value) {
    // Allow only letters, numbers, spaces, hyphens, and periods
    return preg_replace('/[^a-zA-Z0-9 .-]/', '', $value);
}

function generateSSLCertificate($domain, $organization, $validityDays, $country = 'US', $state = 'State', $city = 'City', $email = '', $keySize = 2048, $organizationalUnit = '', $sanList = '') {
    try {
        // Validate inputs
        if (empty($domain) || empty($organization)) {
            throw new Exception("Domain and organization are required");
        }
        
        // Clean domain
        $domain = preg_replace('/^https?:\/\//', '', $domain);
        $domain = preg_replace('/\/.*$/', '', $domain);
        
        if (!filter_var($domain, FILTER_VALIDATE_DOMAIN)) {
            throw new Exception("Invalid domain format");
        }
        
        // Check if OpenSSL is available
        if (!extension_loaded('openssl')) {
            throw new Exception("OpenSSL extension is not available");
        }
        
        // Create downloads directory if it doesn't exist
        $downloadsDir = __DIR__ . '/downloads';
        if (!is_dir($downloadsDir)) {
            if (!mkdir($downloadsDir, 0755, true)) {
                throw new Exception("Cannot create downloads directory");
            }
        }
        
        // Strictly validate countryName
        $country = strtoupper(trim($country));
        if (!preg_match('/^[A-Z]{2}$/', $country)) {
            $country = 'US';
        }
        
        // Trim and sanitize all fields
        $state = sanitize_dn_field(trim($state));
        $city = sanitize_dn_field(trim($city));
        $organization = sanitize_dn_field(trim($organization));
        $organizationalUnit = sanitize_dn_field(trim($organizationalUnit));
        $domain = sanitize_dn_field(trim($domain));
        $email = sanitize_dn_field(trim($email));
        
        // Prevent empty required fields
        if (empty($country)) $country = 'US';
        if (empty($state)) $state = 'State';
        if (empty($city)) $city = 'City';
        if (empty($organization)) $organization = 'Organization';
        if (empty($domain)) throw new Exception('Domain is required');
        
        // Prepare distinguished name
        $dn = array(
            "countryName"            => $country,
            "stateOrProvinceName"    => $state,
            "localityName"           => $city,
            "organizationName"       => $organization,
            "commonName"             => $domain
        );
        
        if (!empty($organizationalUnit)) {
            $dn["organizationalUnitName"] = $organizationalUnit;
        }
        
        if (!empty($email)) {
            $dn["emailAddress"] = $email;
        }
        
        // Generate private key
        $privkey = openssl_pkey_new([
            "private_key_bits" => $keySize,
            "private_key_type" => OPENSSL_KEYTYPE_RSA
        ]);
        
        if (!$privkey) {
            $errors = [];
            while ($error = openssl_error_string()) {
                $errors[] = $error;
            }
            throw new Exception("Failed to generate private key: " . implode(', ', $errors));
        }
        
        // Generate CSR
        $csr = openssl_csr_new($dn, $privkey, ['digest_alg' => 'sha256']);
        
        if (!$csr) {
            $errors = [];
            while ($error = openssl_error_string()) {
                $errors[] = $error;
            }
            throw new Exception("Failed to generate CSR: " . implode(', ', $errors));
        }
        
        // Export private key
        $privateKeyOut = '';
        if (!openssl_pkey_export($privkey, $privateKeyOut)) {
            $errors = [];
            while ($error = openssl_error_string()) {
                $errors[] = $error;
            }
            throw new Exception("Failed to export private key: " . implode(', ', $errors));
        }
        
        // Export CSR
        $csrOut = '';
        if (!openssl_csr_export($csr, $csrOut)) {
            $errors = [];
            while ($error = openssl_error_string()) {
                $errors[] = $error;
            }
            throw new Exception("Failed to export CSR: " . implode(', ', $errors));
        }
        
        // Generate self-signed certificate
        $cert = openssl_csr_sign($csr, null, $privkey, $validityDays, ['digest_alg' => 'sha256']);
        
        if (!$cert) {
            $errors = [];
            while ($error = openssl_error_string()) {
                $errors[] = $error;
            }
            throw new Exception("Failed to generate certificate: " . implode(', ', $errors));
        }
        
        // Export certificate
        $certOut = '';
        if (!openssl_x509_export($cert, $certOut)) {
            $errors = [];
            while ($error = openssl_error_string()) {
                $errors[] = $error;
            }
            throw new Exception("Failed to export certificate: " . implode(', ', $errors));
        }
        
        // Get certificate details
        $certInfo = openssl_x509_parse($cert);
        if (!$certInfo) {
            throw new Exception("Failed to parse certificate information");
        }
        
        // Get key details
        $keyDetails = openssl_pkey_get_details($privkey);
        $actualKeySize = $keyDetails ? $keyDetails['bits'] . ' bits' : 'Unknown';
        
        // Create certificate info text
        $certificateInfo = "=== SSL Certificate Information ===\n\n";
        $certificateInfo .= "Domain: {$domain}\n";
        $certificateInfo .= "Organization: {$organization}\n";
        if (!empty($organizationalUnit)) {
            $certificateInfo .= "Organizational Unit: {$organizationalUnit}\n";
        }
        $certificateInfo .= "Country: {$country}\n";
        $certificateInfo .= "State/Province: {$state}\n";
        $certificateInfo .= "City: {$city}\n";
        if (!empty($email)) {
            $certificateInfo .= "Email: {$email}\n";
        }
        $certificateInfo .= "Key Size: {$actualKeySize}\n";
        $certificateInfo .= "Valid From: " . date('Y-m-d H:i:s', $certInfo['validFrom_time_t']) . "\n";
        $certificateInfo .= "Valid Until: " . date('Y-m-d H:i:s', $certInfo['validTo_time_t']) . "\n";
        $certificateInfo .= "Serial Number: {$certInfo['serialNumber']}\n";
        $certificateInfo .= "Signature Algorithm: {$certInfo['signatureTypeSN']}\n";
        $certificateInfo .= "Certificate Type: Self-Signed\n\n";
        
        $certificateInfo .= "=== Subject Information ===\n";
        foreach ($certInfo['subject'] as $key => $value) {
            $certificateInfo .= ucfirst($key) . ": {$value}\n";
        }
        
        $certificateInfo .= "\n=== Issuer Information ===\n";
        foreach ($certInfo['issuer'] as $key => $value) {
            $certificateInfo .= ucfirst($key) . ": {$value}\n";
        }
        
        return [
            'certificateInfo' => $certificateInfo,
            'privateKey' => $privateKeyOut,
            'csr' => $csrOut,
            'certificate' => $certOut,
            'details' => [
                'domain' => $domain,
                'organization' => $organization,
                'organizationalUnit' => $organizationalUnit,
                'country' => $country,
                'state' => $state,
                'city' => $city,
                'email' => $email,
                'keySize' => $actualKeySize,
                'validFrom' => date('Y-m-d H:i:s', $certInfo['validFrom_time_t']),
                'validTo' => date('Y-m-d H:i:s', $certInfo['validTo_time_t']),
                'serialNumber' => $certInfo['serialNumber'],
                'signatureAlgorithm' => $certInfo['signatureTypeSN']
            ]
        ];
        
    } catch (Exception $e) {
        throw new Exception("Certificate generation failed: " . $e->getMessage());
    }
}

// Main execution
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        returnJson(['success' => false, 'error' => 'POST method required'], 405);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        returnJson(['success' => false, 'error' => 'Invalid JSON input'], 400);
    }
    
    $domain = $input['domain'] ?? '';
    $organization = $input['organization'] ?? '';
    $organizationalUnit = $input['organizationalUnit'] ?? '';
    $country = $input['country'] ?? 'US';
    $state = $input['state'] ?? 'State';
    $city = $input['city'] ?? 'City';
    $email = $input['email'] ?? '';
    $keySize = $input['keySize'] ?? 2048;
    $validityDays = $input['validityDays'] ?? 365;
    $sanList = $input['sanList'] ?? '';
    
    if (empty($domain) || empty($organization)) {
        returnJson(['success' => false, 'error' => 'Domain and organization are required'], 400);
    }
    
    $certificate = generateSSLCertificate($domain, $organization, $validityDays, $country, $state, $city, $email, $keySize, $organizationalUnit, $sanList);
    
    returnJson([
        'success' => true,
        'data' => $certificate
    ]);
    
} catch (Exception $e) {
    file_put_contents(__DIR__ . '/ssl_generate_error.log', date('c') . " Exception: " . $e->getMessage() . "\n", FILE_APPEND);
    returnJson(['success' => false, 'error' => $e->getMessage()], 500);
}
?> 