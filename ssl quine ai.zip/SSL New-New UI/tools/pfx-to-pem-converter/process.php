<?php
header('Content-Type: application/json');

$pfxFile = $_FILES['pfx_file'] ?? null;
$password = $_POST['password'] ?? '';
$extractCert = isset($_POST['extract_cert']);
$extractKey = isset($_POST['extract_key']);
$extractCA = isset($_POST['extract_ca']);

if (!$pfxFile) {
    echo json_encode(['success' => false, 'error' => 'PFX file is required']);
    exit;
}

if ($pfxFile['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => 'File upload failed']);
    exit;
}

try {
    // Read PFX file
    $pfxData = file_get_contents($pfxFile['tmp_name']);
    $originalFilename = $pfxFile['name'];
    
    // Parse PFX file
    $certs = [];
    if (!openssl_pkcs12_read($pfxData, $certs, $password)) {
        throw new Exception('Failed to read PFX file. Check password or file format.');
    }
    
    $files = [];
    $subject = 'Unknown';
    
    // Extract certificate
    if ($extractCert && isset($certs['cert'])) {
        $cert = openssl_x509_read($certs['cert']);
        if ($cert) {
            $certData = openssl_x509_parse($cert);
            $subject = $certData['subject']['CN'] ?? 'Unknown';
        }
        
        $files[] = [
            'name' => 'Certificate',
            'filename' => pathinfo($originalFilename, PATHINFO_FILENAME) . '.crt',
            'content' => $certs['cert'],
            'description' => 'Public certificate file'
        ];
    }
    
    // Extract private key
    if ($extractKey && isset($certs['pkey'])) {
        $files[] = [
            'name' => 'Private Key',
            'filename' => pathinfo($originalFilename, PATHINFO_FILENAME) . '.key',
            'content' => $certs['pkey'],
            'description' => 'Private key file (keep secure!)'
        ];
    }
    
    // Extract CA certificates
    if ($extractCA && isset($certs['extracerts']) && is_array($certs['extracerts'])) {
        $caCerts = implode("\n", $certs['extracerts']);
        $files[] = [
            'name' => 'CA Certificates',
            'filename' => pathinfo($originalFilename, PATHINFO_FILENAME) . '-ca.crt',
            'content' => $caCerts,
            'description' => 'Certificate Authority chain'
        ];
    }
    
    if (empty($files)) {
        throw new Exception('No files selected for extraction or PFX contains no extractable content');
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'original_filename' => $originalFilename,
            'subject' => $subject,
            'files' => $files
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
