<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$ipAddress = $_POST['ip_address'] ?? '';
$port = intval($_POST['port'] ?? 443);

if (empty($ipAddress)) {
    echo json_encode(['success' => false, 'error' => 'IP address is required']);
    exit;
}

// Validate IP address
if (!filter_var($ipAddress, FILTER_VALIDATE_IP)) {
    echo json_encode(['success' => false, 'error' => 'Invalid IP address format']);
    exit;
}

try {
    // Create SSL context
    $context = stream_context_create([
        "ssl" => [
            "capture_peer_cert" => true,
            "verify_peer" => false,
            "verify_peer_name" => false,
            "allow_self_signed" => true,
        ],
    ]);
    
    // Connect to IP address
    $socket = stream_socket_client(
        "ssl://{$ipAddress}:{$port}",
        $errno,
        $errstr,
        30,
        STREAM_CLIENT_CONNECT,
        $context
    );
    
    if (!$socket) {
        throw new Exception("Failed to connect to {$ipAddress}:{$port} - {$errstr} ({$errno})");
    }
    
    // Get certificate
    $cert = stream_context_get_params($socket)['options']['ssl']['peer_certificate'];
    fclose($socket);
    
    if (!$cert) {
        throw new Exception('Failed to retrieve SSL certificate');
    }
    
    // Parse certificate
    $certData = openssl_x509_parse($cert);
    
    // Calculate days until expiry
    $validTo = $certData['validTo_time_t'];
    $now = time();
    $daysUntilExpiry = ceil(($validTo - $now) / 86400);
    
    // Check if expired or expires soon
    $expired = $validTo < $now;
    $expiresSoon = $daysUntilExpiry <= 30 && $daysUntilExpiry > 0;
    
    // Get Subject Alternative Names
    $subjectAltNames = [];
    if (isset($certData['extensions']['subjectAltName'])) {
        $sans = explode(', ', $certData['extensions']['subjectAltName']);
        foreach ($sans as $san) {
            if (strpos($san, 'DNS:') === 0) {
                $subjectAltNames[] = substr($san, 4);
            } elseif (strpos($san, 'IP:') === 0) {
                $subjectAltNames[] = substr($san, 3);
            }
        }
    }
    
    $result = [
        'success' => true,
        'data' => [
            'ip_address' => $ipAddress,
            'port' => $port,
            'common_name' => $certData['subject']['CN'] ?? null,
            'issuer' => $certData['issuer']['CN'] ?? 'Unknown',
            'valid_from' => date('Y-m-d H:i:s', $certData['validFrom_time_t']),
            'valid_to' => date('Y-m-d H:i:s', $certData['validTo_time_t']),
            'days_until_expiry' => $daysUntilExpiry,
            'expired' => $expired,
            'expires_soon' => $expiresSoon,
            'serial_number' => $certData['serialNumber'] ?? 'N/A',
            'signature_algorithm' => $certData['signatureTypeSN'] ?? 'N/A',
            'subject_alt_names' => $subjectAltNames
        ]
    ];
    
    echo json_encode($result);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
