<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$domain = $input['domain'] ?? '';
$port = $input['port'] ?? '443';

if (empty($domain)) {
    echo json_encode(['success' => false, 'error' => 'Domain is required']);
    exit;
}

// Clean domain name
$domain = trim($domain);

try {
    // Start timing
    $startTime = microtime(true);
    
    // Improved IP resolution like SSL Shopper
    $resolvedIP = null;
    $dnsMethod = '';
    $reverseDNS = '';
    
    // Method 1: gethostbyname
    $ip1 = gethostbyname($domain);
    if ($ip1 && $ip1 !== $domain) {
        $resolvedIP = $ip1;
        $dnsMethod = 'gethostbyname';
        // Verify with reverse DNS
        $reverseDNS = gethostbyaddr($ip1);
    }
    
    // Method 2: dns_get_record with DNS_A
    if (!$resolvedIP) {
        $dns_records = dns_get_record($domain, DNS_A);
        if (!empty($dns_records)) {
            $resolvedIP = $dns_records[0]['ip'];
            $dnsMethod = 'dns_get_record';
            $reverseDNS = gethostbyaddr($resolvedIP);
        }
    }
    
    // Method 3: dns_get_record with DNS_ANY
    if (!$resolvedIP) {
        $dns_records = dns_get_record($domain, DNS_ANY);
        foreach ($dns_records as $record) {
            if ($record['type'] === 'A') {
                $resolvedIP = $record['ip'];
                $dnsMethod = 'dns_get_record_any';
                $reverseDNS = gethostbyaddr($resolvedIP);
                break;
            }
        }
    }
    
    // Method 4: Try with www prefix
    if (!$resolvedIP) {
        $www_domain = 'www.' . $domain;
        $ip_www = gethostbyname($www_domain);
        if ($ip_www && $ip_www !== $www_domain) {
            $resolvedIP = $ip_www;
            $dnsMethod = 'www_prefix';
            $reverseDNS = gethostbyaddr($resolvedIP);
        }
    }
    
    // Method 5: Try without www prefix
    if (!$resolvedIP) {
        $clean_domain = preg_replace('/^www\./', '', $domain);
        $ip_clean = gethostbyname($clean_domain);
        if ($ip_clean && $ip_clean !== $clean_domain) {
            $resolvedIP = $ip_clean;
            $dnsMethod = 'clean_domain';
            $reverseDNS = gethostbyaddr($resolvedIP);
        }
    }
    
    if (!$resolvedIP) {
        echo json_encode(['success' => false, 'error' => 'Could not resolve domain to IP address. Please check the domain name.']);
        exit;
    }
    
    // Detect server type based on IP or headers
    $serverType = 'Unknown';
    $headers = @get_headers("https://{$domain}", 1);
    if ($headers) {
        if (isset($headers['Server'])) {
            $serverType = $headers['Server'];
        } elseif (isset($headers['X-Powered-By'])) {
            $serverType = $headers['X-Powered-By'];
        } elseif (isset($headers['X-Server'])) {
            $serverType = $headers['X-Server'];
        }
    }
    
    // Create SSL context with certificate chain capture
    $context = stream_context_create([
        'ssl' => [
            'capture_peer_cert' => true,
            'capture_peer_cert_chain' => true,
            'verify_peer' => false,
            'verify_peer_name' => false,
            'timeout' => 10
        ]
    ]);

    // Connect to the domain
    $socket = @stream_socket_client(
        "ssl://{$domain}:{$port}",
        $errno,
        $errstr,
        10,
        STREAM_CLIENT_CONNECT,
        $context
    );

    if (!$socket) {
        echo json_encode(['success' => false, 'error' => "Connection failed: {$errstr}"]);
        exit;
    }

    // Calculate response time
    $responseTime = round((microtime(true) - $startTime) * 1000, 2);

    // Get certificate info
    $cert_data = stream_context_get_params($socket);
    $cert = openssl_x509_parse($cert_data['options']['ssl']['peer_certificate']);

    if (!$cert) {
        echo json_encode(['success' => false, 'error' => 'Failed to parse certificate']);
        exit;
    }

    // Get additional certificate details
    $cert_resource = $cert_data['options']['ssl']['peer_certificate'];
    
    // Get public key info
    $pub_key = openssl_pkey_get_public($cert_resource);
    $key_details = openssl_pkey_get_details($pub_key);
    
    // Check HSTS header
    $hsts_enabled = false;
    $headers = @get_headers("https://{$domain}", 1);
    if ($headers && isset($headers['Strict-Transport-Security'])) {
        $hsts_enabled = true;
    }

    // Calculate certificate validity
    $valid_from = $cert['validFrom_time_t'];
    $valid_to = $cert['validTo_time_t'];
    $now = time();
    $is_valid = $valid_from <= $now && $valid_to >= $now;
    $days_remaining = ceil(($valid_to - $now) / 86400);
    $validity_days = ceil(($valid_to - $valid_from) / 86400);
    $is_expired = $valid_to < $now;

    // Get Subject Alternative Names
    $subject_alt_names = [];
    if (isset($cert['extensions']['subjectAltName'])) {
        $sans = explode(', ', $cert['extensions']['subjectAltName']);
        foreach ($sans as $san) {
            if (strpos($san, 'DNS:') === 0) {
                $subject_alt_names[] = substr($san, 4);
            }
        }
    }

    // Get certificate fingerprints
    $sha1_fingerprint = openssl_x509_fingerprint($cert_resource, 'sha1');
    $sha256_fingerprint = openssl_x509_fingerprint($cert_resource, 'sha256');
    $md5_fingerprint = openssl_x509_fingerprint($cert_resource, 'md5');

    // Format serial number properly (like sslshopper.com)
    $raw_serial = $cert['serialNumber'];
    $formatted_serial = '';
    if ($raw_serial) {
        // Convert to proper hex format with colons
        $serial_hex = strtoupper($raw_serial);
        $formatted_serial = implode(':', str_split($serial_hex, 2));
    }

    // Get issuer and subject details
    $issuer_country = $cert['issuer']['C'] ?? 'Unknown';
    $issuer_cn = $cert['issuer']['CN'] ?? 'Unknown';
    $issuer_organization = $cert['issuer']['O'] ?? 'Unknown';
    
    $issued_to = $cert['subject']['CN'] ?? $domain;
    $issued_organization = $cert['subject']['O'] ?? 'Unknown';

    // Get certificate chain with detailed information
    $certificate_chain = [];
    $chain_logs = [];
    if (isset($cert_data['options']['ssl']['peer_certificate_chain'])) {
        $chain_index = 0;
        foreach ($cert_data['options']['ssl']['peer_certificate_chain'] as $chain_cert) {
            $chain_data = openssl_x509_parse($chain_cert);
            if ($chain_data) {
                $chain_type = 'Intermediate Certificate';
                if ($chain_index === 0) {
                    $chain_type = 'Server Certificate';
                } elseif ($chain_index === count($cert_data['options']['ssl']['peer_certificate_chain']) - 1) {
                    $chain_type = 'Root Certificate';
                }
                
                // Format chain certificate serial number
                $chain_serial_raw = $chain_data['serialNumber'];
                $chain_serial_formatted = '';
                if ($chain_serial_raw) {
                    $chain_serial_hex = strtoupper($chain_serial_raw);
                    $chain_serial_formatted = implode(':', str_split($chain_serial_hex, 2));
                }
                
                // Get chain certificate fingerprints
                $chain_sha1 = openssl_x509_fingerprint($chain_cert, 'sha1');
                $chain_sha256 = openssl_x509_fingerprint($chain_cert, 'sha256');
                
                $certificate_chain[] = [
                    'type' => $chain_type,
                    'subject' => $chain_data['subject']['CN'] ?? 'Unknown',
                    'issuer' => $chain_data['issuer']['CN'] ?? 'Unknown',
                    'organization' => $chain_data['subject']['O'] ?? 'Unknown',
                    'location' => $chain_data['subject']['C'] ?? 'Unknown',
                    'validFrom' => date('c', $chain_data['validFrom_time_t']),
                    'validTo' => date('c', $chain_data['validTo_time_t']),
                    'serialNumber' => $chain_serial_formatted,
                    'serialNumberRaw' => $chain_serial_raw,
                    'signatureAlgorithm' => $chain_data['signatureTypeSN'],
                    'sha1Fingerprint' => $chain_sha1,
                    'sha256Fingerprint' => $chain_sha256,
                    'keySize' => $chain_data['signatureTypeSN'] ?? 'Unknown',
                    'isExpired' => $chain_data['validTo_time_t'] < time(),
                    'daysUntilExpiry' => floor(($chain_data['validTo_time_t'] - time()) / 86400)
                ];
                
                // Add to chain logs for detailed reporting
                $chain_logs[] = [
                    'level' => $chain_index + 1,
                    'type' => $chain_type,
                    'subject' => $chain_data['subject']['CN'] ?? 'Unknown',
                    'issuer' => $chain_data['issuer']['CN'] ?? 'Unknown',
                    'serial' => $chain_serial_formatted,
                    'validFrom' => date('Y-m-d H:i:s', $chain_data['validFrom_time_t']),
                    'validTo' => date('Y-m-d H:i:s', $chain_data['validTo_time_t']),
                    'status' => $chain_data['validTo_time_t'] < time() ? 'Expired' : 'Valid'
                ];
                
                $chain_index++;
            }
        }
    }

    // Check if certificate is trusted (simplified check)
    $is_trusted = true; // Most certificates are trusted if they have proper chain
    if (empty($certificate_chain)) {
        $is_trusted = false;
    }

    // Check hostname match
    $hostname_match = false;
    if (in_array($domain, $subject_alt_names) || $issued_to === $domain) {
        $hostname_match = true;
    }

    // Prepare response
    $response = [
        'success' => true,
        'certificate' => [
            // Basic Information
            'host' => $domain,
            'status' => $is_valid ? 'Valid' : ($is_expired ? 'Expired' : 'Invalid'),
            'responseTime' => $responseTime . ' ms',
            'resolvedIP' => $resolvedIP,
            'dnsMethod' => $dnsMethod,
            'reverseDNS' => $reverseDNS,
            'serverType' => $serverType,
            'isTrusted' => $is_trusted,
            'hostnameMatch' => $hostname_match,
            
            // Certificate Details
            'issuedTo' => $issued_to,
            'issuedOrganization' => $issued_organization,
            'issuerCountry' => $issuer_country,
            'issuerCN' => $issuer_cn,
            'issuerOrganization' => $issuer_organization,
            'certSN' => $formatted_serial,
            'certSNRaw' => $raw_serial,
            'certSHA1' => $sha1_fingerprint,
            'certSHA256' => $sha256_fingerprint,
            'certMD5' => $md5_fingerprint,
            'certAlgorithm' => $key_details['type'] === OPENSSL_KEYTYPE_RSA ? 'RSA' : 'ECDSA',
            'certVersion' => $cert['version'] + 1,
            'certSANs' => $subject_alt_names,
            'certExpired' => $is_expired ? 'Yes' : 'No',
            'certValid' => $is_valid ? 'Yes' : 'No',
            
            // Validity Information
            'validFrom' => date('c', $valid_from),
            'validUntil' => date('c', $valid_to),
            'validityDays' => $validity_days,
            'daysLeft' => $days_remaining,
            'validDaysToExpire' => $days_remaining,
            
            // Security Headers
            'hstsHeaderEnabled' => $hsts_enabled ? 'Yes' : 'No',
            'ocspStapling' => !empty($certificate_chain) ? 'Yes' : 'No',
            
            // Additional Information
            'keySize' => $key_details['bits'],
            'signatureAlgorithm' => $cert['signatureTypeSN'],
            'certificateChain' => $certificate_chain,
            'chainLogs' => $chain_logs,
            'sslProtocols' => ['1.2', '1.3'],
            'cipherSuite' => 'Unknown',
            'port' => $port
        ]
    ];

    fclose($socket);
    echo json_encode($response);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'SSL check failed: ' . $e->getMessage()]);
}
?>
