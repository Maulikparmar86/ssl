<?php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$csr = $input['csr'] ?? '';

if (empty($csr)) {
    echo json_encode(['success' => false, 'error' => 'CSR data is required']);
    exit;
}

try {
    // Clean the CSR data
    $csr = trim($csr);
    
    // Validate CSR format
    if (!preg_match('/-----BEGIN CERTIFICATE REQUEST-----/', $csr) || !preg_match('/-----END CERTIFICATE REQUEST-----/', $csr)) {
        throw new Exception('Invalid CSR format. Please provide a valid PEM CSR.');
    }
    
    // Parse CSR
    $csr_resource = openssl_csr_new([], $private_key, ['digest_alg' => 'sha256']);
    if (!$csr_resource) {
        throw new Exception('Failed to create CSR resource for parsing.');
    }
    
    // Use openssl_csr_get_subject to get CSR details
    $csr_subject = openssl_csr_get_subject($csr);
    if (!$csr_subject) {
        throw new Exception('Failed to parse CSR subject.');
    }
    
    // Get CSR public key
    $csr_public_key = openssl_csr_get_public_key($csr);
    if (!$csr_public_key) {
        throw new Exception('Failed to extract public key from CSR.');
    }
    
    $key_details = openssl_pkey_get_details($csr_public_key);
    if (!$key_details) {
        throw new Exception('Failed to get public key details.');
    }
    
    // Determine key algorithm
    $key_algorithm = 'Unknown';
    if ($key_details['type'] === OPENSSL_KEYTYPE_RSA) {
        $key_algorithm = 'RSA';
    } elseif ($key_details['type'] === OPENSSL_KEYTYPE_EC) {
        $key_algorithm = 'ECDSA';
    } elseif ($key_details['type'] === OPENSSL_KEYTYPE_DSA) {
        $key_algorithm = 'DSA';
    }
    
    // Get CSR fingerprints
    $sha1_fingerprint = openssl_x509_fingerprint($csr_resource, 'sha1');
    $sha256_fingerprint = openssl_x509_fingerprint($csr_resource, 'sha256');
    
    // Extract CSR details
    $common_name = $csr_subject['CN'] ?? 'Unknown';
    $organization = $csr_subject['O'] ?? '';
    $organizational_unit = $csr_subject['OU'] ?? '';
    $country = $csr_subject['C'] ?? '';
    $state = $csr_subject['ST'] ?? '';
    $locality = $csr_subject['L'] ?? '';
    
    // Get signature algorithm (simplified)
    $signature_algorithm = 'sha256WithRSAEncryption'; // Default, would need more complex parsing
    
    // Get Subject Alternative Names (simplified - would need proper CSR extension parsing)
    $subject_alt_names = [];
    
    // Get public key in PEM format
    $public_key_pem = $key_details['key'];
    
    echo json_encode([
        'success' => true,
        'data' => [
            'commonName' => $common_name,
            'organization' => $organization,
            'organizationalUnit' => $organizational_unit,
            'country' => $country,
            'state' => $state,
            'locality' => $locality,
            'keyAlgorithm' => $key_algorithm,
            'keySize' => $key_details['bits'],
            'signatureAlgorithm' => $signature_algorithm,
            'publicKey' => $public_key_pem,
            'subjectAltNames' => $subject_alt_names,
            'sha1Fingerprint' => $sha1_fingerprint,
            'sha256Fingerprint' => $sha256_fingerprint,
            'checkedAt' => date('Y-m-d H:i:s')
        ]
    ]);
    
    // Clean up resources
    openssl_pkey_free($csr_public_key);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
