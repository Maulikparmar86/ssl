<?php
header('Content-Type: application/json');

$url = $_POST['url'] ?? '';
if (empty($url)) {
    echo json_encode(['success' => false, 'error' => 'URL is required']);
    exit;
}

// Clean and prepare URL
if (!preg_match('/^https?:\/\//', $url)) {
    $url = 'http://' . $url;
}

try {
    $startTime = microtime(true);
    $redirectChain = [];
    $currentUrl = $url;
    $redirectCount = 0;
    $maxRedirects = 10;
    
    // Follow redirects manually to track chain
    while ($redirectCount < $maxRedirects) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $currentUrl);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode >= 300 && $httpCode < 400) {
            // Extract Location header
            if (preg_match('/Location:\s*(.+)/i', $response, $matches)) {
                $newUrl = trim($matches[1]);
                
                // Handle relative URLs
                if (!preg_match('/^https?:\/\//', $newUrl)) {
                    $parsedUrl = parse_url($currentUrl);
                    $newUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'] . $newUrl;
                }
                
                $redirectChain[] = [
                    'from' => $currentUrl,
                    'to' => $newUrl,
                    'code' => $httpCode
                ];
                
                $currentUrl = $newUrl;
                $redirectCount++;
            } else {
                break;
            }
        } else {
            break;
        }
    }
    
    $endTime = microtime(true);
    $responseTime = round(($endTime - $startTime) * 1000);
    
    // Analyze results
    $originalProtocol = parse_url($url, PHP_URL_SCHEME);
    $finalProtocol = parse_url($currentUrl, PHP_URL_SCHEME);
    
    $httpsRedirect = ($originalProtocol === 'http' && $finalProtocol === 'https');
    
    echo json_encode([
        'success' => true,
        'data' => [
            'original_url' => $url,
            'final_url' => $currentUrl,
            'original_protocol' => $originalProtocol,
            'final_protocol' => $finalProtocol,
            'https_redirect' => $httpsRedirect,
            'redirect_count' => $redirectCount,
            'redirect_chain' => $redirectChain,
            'response_time' => $responseTime
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
