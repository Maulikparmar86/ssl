<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$hostname = $_POST['hostname'] ?? '';
$timeout = intval($_POST['timeout'] ?? 10);

if (empty($hostname)) {
    echo json_encode(['success' => false, 'error' => 'Hostname is required']);
    exit;
}

// Clean hostname
$hostname = preg_replace('/^https?:\/\//', '', $hostname);
$hostname = preg_replace('/\/.*$/', '', $hostname);

try {
    $startTime = microtime(true);
    
    // Resolve IP address
    $ipAddress = gethostbyname($hostname);
    if ($ipAddress === $hostname && !filter_var($hostname, FILTER_VALIDATE_IP)) {
        throw new Exception('Unable to resolve hostname to IP address');
    }
    
    // Test port 443 connectivity
    $socket = @fsockopen($hostname, 443, $errno, $errstr, $timeout);
    $portOpen = ($socket !== false);
    
    if ($socket) {
        fclose($socket);
    }
    
    $endTime = microtime(true);
    $responseTime = round(($endTime - $startTime) * 1000);
    
    // Test SSL availability
    $sslAvailable = false;
    $errorMessage = '';
    
    if ($portOpen) {
        try {
            $context = stream_context_create([
                "ssl" => [
                    "verify_peer" => false,
                    "verify_peer_name" => false,
                ],
            ]);
            
            $sslSocket = @stream_socket_client(
                "ssl://{$hostname}:443",
                $sslErrno,
                $sslErrstr,
                5,
                STREAM_CLIENT_CONNECT,
                $context
            );
            
            if ($sslSocket) {
                $sslAvailable = true;
                fclose($sslSocket);
            } else {
                $errorMessage = "SSL connection failed: {$sslErrstr}";
            }
        } catch (Exception $e) {
            $errorMessage = "SSL test error: " . $e->getMessage();
        }
    } else {
        $errorMessage = "Port 443 connection failed: {$errstr} ({$errno})";
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'hostname' => $hostname,
            'ip_address' => $ipAddress,
            'port_open' => $portOpen,
            'ssl_available' => $sslAvailable,
            'response_time' => $responseTime,
            'error_message' => $errorMessage
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
