<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$hostname = $_POST['hostname'] ?? '';
$certificate = $_POST['certificate'] ?? '';
$ipAddress = $_POST['ip_address'] ?? '';
$ipPort = intval($_POST['ip_port'] ?? 443);
$outputFormat = $_POST['output_format'] ?? 'list';

if (empty($hostname) && empty($certificate) && empty($ipAddress)) {
    echo json_encode(['success' => false, 'error' => 'Either hostname, certificate, or IP address is required']);
    exit;
}

try {
    $cert = null;
    
    if (!empty($hostname)) {
        // Get certificate from hostname
        $hostname = preg_replace('/^https?:\/\//', '', $hostname);
        $hostname = preg_replace('/\/.*$/', '', $hostname);
        
        $context = stream_context_create([
            "ssl" => [
                "capture_peer_cert" => true,
                "verify_peer" => false,
                "verify_peer_name" => false,
            ],
        ]);
        
        $socket = stream_socket_client("ssl://{$hostname}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
        
        if (!$socket) {
            throw new Exception("Failed to connect: $errstr");
        }
        
        $cert = stream_context_get_params($socket)['options']['ssl']['peer_certificate'];
        fclose($socket);
        
    } elseif (!empty($ipAddress)) {
        // Get certificate from IP address
        if (!filter_var($ipAddress, FILTER_VALIDATE_IP)) {
            throw new Exception('Invalid IP address format');
        }
        
        $context = stream_context_create([
            "ssl" => [
                "capture_peer_cert" => true,
                "verify_peer" => false,
                "verify_peer_name" => false,
            ],
        ]);
        
        $socket = stream_socket_client("ssl://{$ipAddress}:{$ipPort}", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
        
        if (!$socket) {
            throw new Exception("Failed to connect to {$ipAddress}:{$ipPort} - $errstr");
        }
        
        $cert = stream_context_get_params($socket)['options']['ssl']['peer_certificate'];
        fclose($socket);
        
    } else {
        // Use provided certificate
        $cert = openssl_x509_read($certificate);
        if (!$cert) {
            throw new Exception('Invalid certificate format');
        }
    }
    
    $certData = openssl_x509_parse($cert);
    
    // Get Common Name
    $commonName = $certData['subject']['CN'] ?? null;
    
    // Get Subject Alternative Names
    $subjectAltNames = [];
    $allHostnames = [];
    $wildcardCount = 0;
    
    if (isset($certData['extensions']['subjectAltName'])) {
        $sans = explode(', ', $certData['extensions']['subjectAltName']);
        foreach ($sans as $san) {
            if (strpos($san, 'DNS:') === 0) {
                $hostname = substr($san, 4);
                $subjectAltNames[] = $hostname;
                $allHostnames[] = $hostname;
                
                if (strpos($hostname, '*.') === 0) {
                    $wildcardCount++;
                }
            } elseif (strpos($san, 'IP:') === 0) {
                $ip = substr($san, 3);
                $subjectAltNames[] = $ip;
                $allHostnames[] = $ip;
            }
        }
    }
    
    // Add Common Name to hostnames if not already present
    if ($commonName && !in_array($commonName, $allHostnames)) {
        array_unshift($allHostnames, $commonName);
        if (strpos($commonName, '*.') === 0) {
            $wildcardCount++;
        }
    }
    
    // Remove duplicates and sort
    $allHostnames = array_unique($allHostnames);
    sort($allHostnames);
    
    $result = [
        'success' => true,
        'data' => [
            'common_name' => $commonName,
            'subject_alt_names' => $subjectAltNames,
            'all_hostnames' => $allHostnames,
            'hostname_count' => count($allHostnames),
            'wildcard_count' => $wildcardCount,
            'certificate_info' => [
                'issuer' => $certData['issuer']['CN'] ?? 'Unknown',
                'valid_from' => date('Y-m-d', $certData['validFrom_time_t']),
                'valid_to' => date('Y-m-d', $certData['validTo_time_t']),
                'serial_number' => $certData['serialNumber'] ?? 'N/A'
            ]
        ]
    ];
    
    echo json_encode($result);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
