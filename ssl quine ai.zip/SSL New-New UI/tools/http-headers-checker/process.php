<?php
header('Content-Type: application/json');

$url = $_POST['url'] ?? '';
$method = $_POST['method'] ?? 'GET';
$headersToCheck = $_POST['headers'] ?? [];

if (empty($url)) {
    echo json_encode(['success' => false, 'error' => 'URL is required']);
    exit;
}

if (empty($headersToCheck)) {
    echo json_encode(['success' => false, 'error' => 'At least one header must be selected']);
    exit;
}

// Validate URL
if (!filter_var($url, FILTER_VALIDATE_URL)) {
    echo json_encode(['success' => false, 'error' => 'Invalid URL format']);
    exit;
}

try {
    $startTime = microtime(true);
    
    // Make HTTP request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, $method === 'HEAD');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'SSL-Checker-Pro/1.0');
    
    $response = curl_exec($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    
    $endTime = microtime(true);
    $responseTime = round(($endTime - $startTime) * 1000);
    
    if ($response === false) {
        throw new Exception('Failed to fetch URL');
    }
    
    // Parse headers
    $headerString = substr($response, 0, $headerSize);
    $headerLines = explode("\r\n", $headerString);
    $headers = [];
    
    foreach ($headerLines as $line) {
        if (strpos($line, ':') !== false) {
            list($name, $value) = explode(':', $line, 2);
            $headers[strtolower(trim($name))] = trim($value);
        }
    }
    
    // Define security headers to check
    $securityHeaders = [
        'hsts' => [
            'name' => 'HTTP Strict Transport Security (HSTS)',
            'header' => 'strict-transport-security',
            'description' => 'Forces browsers to use HTTPS connections and prevents protocol downgrade attacks.',
            'severity' => 'high',
            'recommendation' => 'Add: Strict-Transport-Security: max-age=31536000; includeSubDomains'
        ],
        'csp' => [
            'name' => 'Content Security Policy (CSP)',
            'header' => 'content-security-policy',
            'description' => 'Controls which resources can be loaded, preventing XSS and data injection attacks.',
            'severity' => 'high',
            'recommendation' => 'Add: Content-Security-Policy: default-src \'self\''
        ],
        'xframe' => [
            'name' => 'X-Frame-Options',
            'header' => 'x-frame-options',
            'description' => 'Prevents clickjacking attacks by controlling iframe embedding.',
            'severity' => 'medium',
            'recommendation' => 'Add: X-Frame-Options: DENY or SAMEORIGIN'
        ],
        'xcontent' => [
            'name' => 'X-Content-Type-Options',
            'header' => 'x-content-type-options',
            'description' => 'Prevents MIME type sniffing attacks.',
            'severity' => 'medium',
            'recommendation' => 'Add: X-Content-Type-Options: nosniff'
        ],
        'xss' => [
            'name' => 'X-XSS-Protection',
            'header' => 'x-xss-protection',
            'description' => 'Enables browser XSS filtering (legacy, use CSP instead).',
            'severity' => 'low',
            'recommendation' => 'Add: X-XSS-Protection: 1; mode=block'
        ],
        'referrer' => [
            'name' => 'Referrer-Policy',
            'header' => 'referrer-policy',
            'description' => 'Controls how much referrer information is sent with requests.',
            'severity' => 'low',
            'recommendation' => 'Add: Referrer-Policy: strict-origin-when-cross-origin'
        ]
    ];
    
    $results = [];
    $presentCount = 0;
    
    foreach ($headersToCheck as $headerKey) {
        if (!isset($securityHeaders[$headerKey])) {
            continue;
        }
        
        $headerInfo = $securityHeaders[$headerKey];
        $headerName = $headerInfo['header'];
        $present = isset($headers[$headerName]);
        
        if ($present) {
            $presentCount++;
        }
        
        $results[] = [
            'name' => $headerInfo['name'],
            'present' => $present,
            'value' => $present ? $headers[$headerName] : null,
            'description' => $headerInfo['description'],
            'severity' => $headerInfo['severity'],
            'recommendation' => $present ? null : $headerInfo['recommendation']
        ];
    }
    
    // Generate overall recommendation
    $totalHeaders = count($results);
    $percentage = $totalHeaders > 0 ? round(($presentCount / $totalHeaders) * 100) : 0;
    
    $recommendation = '';
    if ($percentage >= 80) {
        $recommendation = 'Excellent security header implementation! Consider fine-tuning existing headers for optimal security.';
    } elseif ($percentage >= 60) {
        $recommendation = 'Good security header coverage. Add the missing headers to improve security further.';
    } elseif ($percentage >= 40) {
        $recommendation = 'Fair security header implementation. Several important headers are missing - prioritize adding them.';
    } else {
        $recommendation = 'Poor security header implementation. Critical security headers are missing - implement them immediately.';
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'url' => $url,
            'status_code' => $statusCode,
            'response_time' => $responseTime,
            'headers' => $results,
            'recommendation' => $recommendation
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
