<?php
header('Content-Type: application/json');

$hostname = $_POST['hostname'] ?? '';
$certificate = $_POST['certificate'] ?? '';

if (empty($hostname) && empty($certificate)) {
    echo json_encode(['success' => false, 'error' => 'Either hostname or certificate is required']);
    exit;
}

try {
    $cert = null;
    
    if (!empty($hostname)) {
        // Get certificate from hostname
        $hostname = preg_replace('/^https?:\/\//', '', $hostname);
        $hostname = preg_replace('/\/.*$/', '', $hostname);
        
        $context = stream_context_create([
            "ssl" => [
                "capture_peer_cert" => true,
                "verify_peer" => false,
                "verify_peer_name" => false,
            ],
        ]);
        
        $socket = stream_socket_client("ssl://{$hostname}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
        
        if (!$socket) {
            throw new Exception("Failed to connect: $errstr");
        }
        
        $cert = stream_context_get_params($socket)['options']['ssl']['peer_certificate'];
        fclose($socket);
        
    } else {
        // Use provided certificate
        $cert = openssl_x509_read($certificate);
        if (!$cert) {
            throw new Exception('Invalid certificate format');
        }
    }
    
    $certData = openssl_x509_parse($cert);
    
    // Extract Subject Alternative Names
    $sanList = [];
    $hasWildcard = false;
    
    if (isset($certData['extensions']['subjectAltName'])) {
        $sans = explode(', ', $certData['extensions']['subjectAltName']);
        foreach ($sans as $san) {
            if (strpos($san, 'DNS:') === 0) {
                $domain = substr($san, 4);
                $sanList[] = $domain;
                if (strpos($domain, '*') !== false) {
                    $hasWildcard = true;
                }
            } elseif (strpos($san, 'IP:') === 0) {
                $sanList[] = substr($san, 3) . ' (IP Address)';
            }
        }
    }
    
    // Add Common Name if not in SAN
    $commonName = $certData['subject']['CN'] ?? 'Unknown';
    if (!in_array($commonName, $sanList)) {
        array_unshift($sanList, $commonName . ' (Common Name)');
    }
    
    // Determine certificate type
    $certType = 'Single Domain';
    if (count($sanList) > 1) {
        if ($hasWildcard) {
            $certType = count($sanList) > 2 ? 'Multi-Domain Wildcard' : 'Wildcard';
        } else {
            $certType = 'Multi-Domain (SAN)';
        }
    } elseif ($hasWildcard) {
        $certType = 'Wildcard';
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'common_name' => $commonName,
            'san_list' => $sanList,
            'san_count' => count($sanList),
            'cert_type' => $certType,
            'has_wildcard' => $hasWildcard,
            'valid_until' => date('Y-m-d H:i:s', $certData['validTo_time_t'])
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
