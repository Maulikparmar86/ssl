<?php
header('Content-Type: application/json');

$hostname = $_POST['hostname'] ?? '';
$port = intval($_POST['port'] ?? 443);
$protocols = $_POST['protocols'] ?? [];

if (empty($hostname)) {
    echo json_encode(['success' => false, 'error' => 'Hostname is required']);
    exit;
}

if (empty($protocols)) {
    echo json_encode(['success' => false, 'error' => 'At least one protocol must be selected']);
    exit;
}

$hostname = preg_replace('/^https?:\/\//', '', $hostname);
$hostname = preg_replace('/\/.*$/', '', $hostname);

try {
    $results = [];
    
    // Protocol mapping for OpenSSL
    $protocolMap = [
        'ssl2' => STREAM_CRYPTO_METHOD_SSLv2_CLIENT,
        'ssl3' => STREAM_CRYPTO_METHOD_SSLv3_CLIENT,
        'tls1' => STREAM_CRYPTO_METHOD_TLSv1_0_CLIENT,
        'tls1_1' => STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT,
        'tls1_2' => STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT,
        'tls1_3' => STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT
    ];
    
    foreach ($protocols as $protocol) {
        if (!isset($protocolMap[$protocol])) {
            continue;
        }
        
        $supported = false;
        $error = null;
        
        try {
            $context = stream_context_create([
                "ssl" => [
                    "verify_peer" => false,
                    "verify_peer_name" => false,
                    "crypto_method" => $protocolMap[$protocol]
                ]
            ]);
            
            $socket = @stream_socket_client(
                "ssl://{$hostname}:{$port}",
                $errno,
                $errstr,
                10,
                STREAM_CLIENT_CONNECT,
                $context
            );
            
            if ($socket) {
                $supported = true;
                fclose($socket);
            } else {
                $error = $errstr;
            }
            
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
        
        $results[] = [
            'version' => $protocol,
            'supported' => $supported,
            'error' => $error
        ];
    }
    
    // Generate recommendation
    $secureProtocols = array_filter($results, function($r) {
        return $r['supported'] && in_array($r['version'], ['tls1_2', 'tls1_3']);
    });
    
    $insecureProtocols = array_filter($results, function($r) {
        return $r['supported'] && in_array($r['version'], ['ssl2', 'ssl3', 'tls1', 'tls1_1']);
    });
    
    $recommendation = '';
    if (count($insecureProtocols) > 0) {
        $recommendation = 'Disable insecure protocols (SSLv2, SSLv3, TLS 1.0, TLS 1.1) and use only TLS 1.2 and TLS 1.3.';
    } elseif (count($secureProtocols) > 0) {
        $recommendation = 'Good! Your server supports secure protocols. Consider enabling TLS 1.3 if not already enabled.';
    } else {
        $recommendation = 'Critical: No secure protocols detected. Enable TLS 1.2 and TLS 1.3 immediately.';
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'hostname' => $hostname,
            'port' => $port,
            'protocols' => $results,
            'recommendation' => $recommendation
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
