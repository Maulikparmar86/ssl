// SSL Checker Pro - Main JavaScript

// Navigation functions
function showPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show selected page
    document.getElementById(pageId).classList.add('active');
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Find and activate the corresponding nav link
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        if (link.textContent.toLowerCase() === pageId) {
            link.classList.add('active');
        }
    });
}

// Tool navigation function
function showTool(toolId) {
    // Redirect to individual tool pages
    const toolPages = {
        'ssl-checker': '/tools/ssl-checker/',
        'csr-generator': '/tools/csr-generator/',
        'certificate-decoder': '/tools/certificate-decoder/',
        'ssl-expiry-checker': '/tools/ssl-expiry-checker/',
        'website-trust-logo': '/tools/website-trust-logo-embed/',
        'hostname-from-ssl': '/tools/hostname-from-ssl/',
        'ip-to-hostname-ssl': '/tools/ip-to-hostname-ssl/',
        'ocsp-crl-checker': '/tools/ocsp-crl-checker/',
        'http-headers-checker': '/tools/http-headers-checker/',
        'ssl-protocol-support': '/tools/ssl-protocol-support/',
        'pfx-to-pem-converter': '/tools/pfx-to-pem-converter/',
        'der-to-pem-converter': '/tools/der-to-pem-converter/',
        'pem-to-der-converter': '/tools/pem-to-der-converter/',
        'certificate-san-checker': '/tools/certificate-san-checker/',
        'ssl-vulnerability-scanner': '/tools/ssl-vulnerability-scanner/',
        'ssl-chain-checker': '/tools/ssl-chain-checker/',
        'certificate-fingerprint': '/tools/certificate-fingerprint/',
        'port-443-test': '/tools/port-443-test/',
        'https-redirect-checker': '/tools/https-redirect-checker/',
        'domain-expiry-checker': '/tools/domain-expiry-checker/',
        'private-key-matcher': '/tools/private-key-matcher/',
        'csr-decoder': '/tools/csr-decoder/'
    };
    
    if (toolPages[toolId]) {
        window.location.href = toolPages[toolId];
    }
}

// Scroll to tools section
function scrollToTools() {
    document.getElementById('tools').scrollIntoView({ 
        behavior: 'smooth' 
    });
}

// Highlight current page in navigation
function highlightCurrentPage() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        const href = link.getAttribute('href');
        
        if (href) {
            if (currentPath === href || 
                (currentPath === '/' && href === '/') ||
                (currentPath.startsWith('/blogs') && href === '/blogs/') ||
                (currentPath.includes('/tools/') && href.includes('/tools/')) ||
                (currentPath === '/about.html' && href === '/about.html') ||
                (currentPath === '/contact.html' && href === '/contact.html')) {
                link.classList.add('active');
            }
        }
    });
}

// Mobile menu toggle
function initMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            this.classList.toggle('active');
            document.getElementById('navMenu').classList.toggle('mobile-active');
        });
    }
}

// Close mobile menu when clicking on a link
function initNavLinks() {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            if (mobileMenuBtn) {
                mobileMenuBtn.classList.remove('active');
                document.getElementById('navMenu').classList.remove('mobile-active');
            }
        });
    });
}

// Smooth scrolling for anchor links
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Initialize tool cards
function initToolCards() {
    document.querySelectorAll('.tool-card').forEach(card => {
        card.addEventListener('click', function() {
            const toolId = this.getAttribute('data-tool');
            if (toolId) {
                showTool(toolId);
            }
        });
    });
}

// Initialize page
function initPage() {
    // Show home page by default
    const homePage = document.getElementById('home');
    if (homePage) {
        homePage.classList.add('active');
    }
    
    // Highlight current page in navigation
    highlightCurrentPage();
}

// SSL Checker Form Handler
function initSslCheckerForm() {
    const form = document.getElementById('sslCheckerForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const domain = document.getElementById('domain').value;
            const resultsSection = document.getElementById('sslResults');
            const resultsContent = document.getElementById('sslResultsContent');
            
            // Show loading state
            resultsContent.innerHTML = '<p>Checking SSL certificate...</p>';
            resultsSection.style.display = 'block';
            
            // Simulate API call
  setTimeout(() => {
                const mockResults = {
                    domain: domain,
                    issuer: 'Let\'s Encrypt Authority X3',
                    validFrom: '2024-01-01 00:00:00 UTC',
                    validTo: '2024-04-01 23:59:59 UTC',
                    daysRemaining: 45,
                    status: 'Valid'
                };
                
                resultsContent.innerHTML = `
                    <div class="result-item">
                        <div class="result-label">Domain</div>
                        <div class="result-value">${mockResults.domain}</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">Issuer</div>
                        <div class="result-value">${mockResults.issuer}</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">Valid From</div>
                        <div class="result-value">${mockResults.validFrom}</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">Valid Until</div>
                        <div class="result-value">${mockResults.validTo}</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">Days Remaining</div>
                        <div class="result-value">${mockResults.daysRemaining} days</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">Status</div>
                        <div class="result-value status-success">${mockResults.status}</div>
                    </div>
                `;
                
                // Scroll to results
                resultsSection.scrollIntoView({ behavior: 'smooth' });
            }, 2000);
        });
    }
}

// CSR Generator Form Handler
function initCsrGeneratorForm() {
    const form = document.getElementById('csrForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const commonName = document.getElementById('commonName').value;
            const organization = document.getElementById('organization').value;
            const country = document.getElementById('country').value;
            
            const resultsSection = document.getElementById('results');
            const resultsContent = document.getElementById('resultsContent');
            
            // Show loading state
            resultsContent.innerHTML = '<p>Generating CSR...</p>';
            resultsSection.style.display = 'block';
            
            // Simulate API call
            setTimeout(() => {
                const mockCSR = `-----BEGIN CERTIFICATE REQUEST-----
MIICvDCCAaQCAQAwdzELMAkGA1UEBhMCVVMxDTALBgNVBAgMBFV0YWgxDzAN
BgNVBAcMBlByb3ZvMQ8wDQYDVQQKDAZHT09HTEUxGzAZBgNVBAsMElRlY2hu
aWNhbCBTdXBwb3J0MRMwEQYDVQQDDAp0ZXN0LmNvbTEaMBgGCSqGSIb3DQEJ
ARYLdGVzdEB0ZXN0LmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
ggEBALtUlNS31SzxKXzLgYfFmkvsqcZtPd12jWJcvobGcBMvBxX4YqNG1OQo
...`;
                
                resultsContent.innerHTML = `
                    <div class="result-item">
                        <div class="result-label">Common Name</div>
                        <div class="result-value">${commonName}</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">Organization</div>
                        <div class="result-value">${organization}</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">Country</div>
                        <div class="result-value">${country}</div>
                    </div>
                    <div class="result-item">
                        <div class="result-label">CSR (Certificate Signing Request)</div>
                        <div class="result-value">${mockCSR}</div>
                    </div>
                `;
                
                // Scroll to results
                resultsSection.scrollIntoView({ behavior: 'smooth' });
            }, 2000);
        });
    }
}

// Initialize all functionality when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initPage();
    initMobileMenu();
    initNavLinks();
    initSmoothScrolling();
    initToolCards();
    initSslCheckerForm();
    initCsrGeneratorForm();
    
    // Highlight current page after a short delay to ensure header is loaded
    setTimeout(() => {
        highlightCurrentPage();
    }, 100);
});
